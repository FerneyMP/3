#ifndef METODO2_H
#define METODO2_H
#include "funciones_principales.h"

bool codificacion(int semilla, string n_arhivo, string n_archivo2);
string reglas_codifica(string binario, int semilla);
string metodo2(string pedazo);
string binario_texto(string binario);
char conv_letra(string pedazo);

#endif // METODO2_H

#include "metodo_2.h"

/*
 * string ----- decodificacion
leer el archivo en modo binario
convetir a binario
aplicar las reglas de decodificacion (rotaciones a la derecha >> para obtener el binario decodificado )
    se mueve una unidad
convertir a archiv de texto
escribir en modo convencional

*/


int main()
{
   crear_txt("datos.dat");

    //decodificacion(4,"codificado.dat","natural.txt");
    return 0;
}


/* fstream text ("ensayo.txt",fstream::out);
    cout<<"hello"<<endl;*/




#ifndef FUNCIONES_H
#define FUNCIONES_H

#include <iostream>
using namespace std;

bool val(string usuario, string clave);



#endif // FUNCIONES_H

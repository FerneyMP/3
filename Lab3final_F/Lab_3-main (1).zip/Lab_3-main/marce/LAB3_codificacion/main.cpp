#include "metodo_2.h"

//crear con memoria dinamica unos arreglos de char para almacnar los caracteres del archivo
//guardar el binario resultante de cada uno de esos caracteres
//caracter - numero entero - ascii - numero binario de 8 bits


int main()
{
    codificacion(4,"natural.txt","codificado.dat");
    //"codificado.dat"
    return 0;
}


/* fstream text ("ensayo.txt",fstream::out);
    cout<<"hello"<<endl;*/



